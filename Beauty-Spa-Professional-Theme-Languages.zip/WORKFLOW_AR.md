# طريقة رفع Beauty & Spa إلى GitHub Pages

1. فك ضغط الملف على هاتفك أو حاسوبك.
2. ارفع **محتويات المجلد** إلى مستودع GitHub، وليس ملف ZIP نفسه فقط.
3. تأكد أن الفرع اسمه `main` وأن الملف `.github/workflows/deploy-pages.yml` مرفوع.
4. من Settings → Pages اختر Source: GitHub Actions.
5. افتح Actions وانتظر نجاح `Deploy Beauty & Spa to GitHub Pages`.

الـ workflow يبحث عن `public/index.html` أولاً، ثم عن `index.html` في الجذر. إذا كان لديك workflow قديم آخر يفشل، عطّله أو احذفه حتى لا يتعارض مع هذا الملف.

## Supabase
- إعدادات الاتصال موجودة في `.env.example` كمرجع.
- لا تضع `service_role` أو مفاتيح سرية داخل ملفات الواجهة العامة.
- دوال Edge Functions وملف SQL تحتاج إلى نشر/تنفيذ منفصل في Supabase؛ GitHub Pages لا ينشرها تلقائياً.
