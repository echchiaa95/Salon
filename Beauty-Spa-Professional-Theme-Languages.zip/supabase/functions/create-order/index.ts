import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);

  try {
    const body = await req.json();
    const { salon_id, customer_name, customer_phone, customer_email, shipping_city, shipping_address, notes, items } = body ?? {};

    if (!salon_id || !customer_name || !customer_phone || !shipping_address || !Array.isArray(items) || items.length === 0) {
      return json({ error: "بيانات الطلب غير مكتملة" }, 400);
    }
    if (String(customer_name).length > 120 || String(customer_phone).length > 40 ||
        String(shipping_address).length > 500 || items.length > 30) {
      return json({ error: "تجاوزت بعض البيانات الحد المسموح" }, 400);
    }

    const url = Deno.env.get("SUPABASE_URL");
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    if (!url || !serviceKey) return json({ error: "Server configuration missing" }, 500);

    // Service key is used only inside the Edge Function, never in the browser.
    const db = createClient(url, serviceKey, { auth: { persistSession: false } });

    const productIds = [...new Set(items.map((x: any) => String(x.product_id ?? "")))];
    if (productIds.some((id) => !id) || items.some((x: any) => !Number.isInteger(x.quantity) || x.quantity < 1 || x.quantity > 50)) {
      return json({ error: "منتجات أو كميات غير صالحة" }, 400);
    }

    const { data: products, error: productsError } = await db
      .from("products")
      .select("id,salon_id,name,price,stock_quantity,is_active")
      .eq("salon_id", salon_id)
      .in("id", productIds)
      .eq("is_active", true);

    if (productsError) throw productsError;
    if (!products || products.length !== productIds.length) return json({ error: "أحد المنتجات غير متاح" }, 400);

    const byId = new Map(products.map((p: any) => [p.id, p]));
    const resolved = items.map((x: any) => {
      const p: any = byId.get(String(x.product_id));
      if (!p) throw new Error("منتج غير صالح");
      if (p.stock_quantity < x.quantity) throw new Error(`الكمية غير متوفرة للمنتج: ${p.name}`);
      return { product_id: p.id, product_name: p.name, unit_price: Number(p.price), quantity: x.quantity };
    });

    const subtotal = resolved.reduce((sum, x) => sum + x.unit_price * x.quantity, 0);
    const { data: salon, error: salonError } = await db
      .from("salons").select("delivery_fee").eq("id", salon_id).single();
    if (salonError || !salon) return json({ error: "الصالون غير موجود" }, 404);

    const delivery = Number(salon.delivery_fee ?? 0);
    const { data: order, error: orderError } = await db.from("orders").insert({
      salon_id,
      customer_name: String(customer_name).trim(),
      customer_phone: String(customer_phone).trim(),
      customer_email: customer_email ? String(customer_email).trim() : null,
      shipping_city: shipping_city ? String(shipping_city).trim() : null,
      shipping_address: String(shipping_address).trim(),
      notes: notes ? String(notes).slice(0, 1000) : null,
      subtotal,
      delivery_fee: delivery,
      total: subtotal + delivery,
      payment_method: "cod",
      payment_status: "unpaid",
      status: "pending",
    }).select("id,order_number,total,status").single();

    if (orderError || !order) throw orderError ?? new Error("Could not create order");

    const { error: itemError } = await db.from("order_items").insert(
      resolved.map((x) => ({ ...x, order_id: order.id })),
    );
    if (itemError) {
      await db.from("orders").delete().eq("id", order.id);
      throw itemError;
    }

    return json({ success: true, order });
  } catch (err) {
    const message = err instanceof Error ? err.message : "حدث خطأ غير متوقع";
    return json({ error: message }, 400);
  }
});
