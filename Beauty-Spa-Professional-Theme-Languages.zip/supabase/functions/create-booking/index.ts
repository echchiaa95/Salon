import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...corsHeaders, "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);

  try {
    const body = await req.json();
    const { salon_id, service_id, customer_name, customer_phone, customer_email, requested_at, notes } = body ?? {};
    if (!salon_id || !customer_name || !customer_phone || !requested_at || (!service_id && !body.service_name)) {
      return json({ error: "بيانات الحجز غير مكتملة" }, 400);
    }
    if (String(customer_name).length > 120 || String(customer_phone).length > 40 || String(notes ?? "").length > 1000) {
      return json({ error: "تجاوزت بعض البيانات الحد المسموح" }, 400);
    }
    const date = new Date(requested_at);
    if (Number.isNaN(date.getTime()) || date.getTime() < Date.now() - 60_000 || date.getTime() > Date.now() + 180 * 24 * 60 * 60 * 1000) {
      return json({ error: "تاريخ الحجز غير صالح" }, 400);
    }

    const url = Deno.env.get("SUPABASE_URL");
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    if (!url || !serviceKey) return json({ error: "Server configuration missing" }, 500);
    const db = createClient(url, serviceKey, { auth: { persistSession: false } });

    let serviceName = String(body.service_name ?? "").trim();
    if (service_id) {
      const { data: service, error } = await db.from("services")
        .select("id,name,salon_id,is_active").eq("id", service_id).eq("salon_id", salon_id).eq("is_active", true).single();
      if (error || !service) return json({ error: "الخدمة غير متاحة" }, 400);
      serviceName = service.name;
    }
    if (!serviceName || serviceName.length > 160) return json({ error: "اسم الخدمة غير صالح" }, 400);

    const { data, error } = await db.from("bookings").insert({
      salon_id,
      service_id: service_id || null,
      service_name: serviceName,
      customer_name: String(customer_name).trim(),
      customer_phone: String(customer_phone).trim(),
      customer_email: customer_email ? String(customer_email).trim() : null,
      requested_at: date.toISOString(),
      notes: notes ? String(notes).trim() : null,
      status: "pending",
    }).select("id,service_name,requested_at,status").single();

    if (error) throw error;
    return json({ success: true, booking: data });
  } catch (err) {
    return json({ error: err instanceof Error ? err.message : "حدث خطأ غير متوقع" }, 400);
  }
});
