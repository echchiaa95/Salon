# Beauty & Spa

قالب موقع تجميلي يدعم العربية والفرنسية والإنجليزية، مع الوضع الليلي والنهاري، وملفات Supabase.

للنشر من ZIP، راجع `WORKFLOW_AR.md`. ملف Workflow الموجود في `.github/workflows/deploy-pages.yml` يبحث عن أحدث ZIP في جذر مستودع `Salon`، يستخرجه، ثم ينشر صفحة الموقع إلى GitHub Pages.

موقع GitHub Pages: https://echchiaa95.github.io/Salon/

ملاحظة: GitHub Pages ينشر الواجهة الأمامية فقط. انشر SQL وEdge Functions الموجودة في `supabase/` إلى Supabase بشكل مستقل.
