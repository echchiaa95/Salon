# Beauty & Spa — رفع ZIP وتشغيل Workflow موحد

## الطريقة الموصى بها
1. افتح مستودع GitHub `Salon`.
2. ضع ملف ZIP النهائي في جذر المستودع (نفس مستوى مجلد `.github`). لا تضعه داخل مجلد فرعي.
3. تأكد أن الملف `.github/workflows/deploy-pages.yml` الموجود في المستودع هو النسخة الموجودة في هذا المشروع. إذا كان لديك Workflow قديم، استبدله بهذه النسخة مرة واحدة.
4. اجعل اسم الفرع `main`، ومن Settings → Pages اختر `GitHub Actions`.
5. افتح Actions. كل عملية رفع ZIP إلى الفرع `main` تشغّل النشر تلقائيًا. ويمكن تشغيله يدويًا من Run workflow.

الـ Workflow يتعامل مع ZIP في جذر المستودع حتى لو اختلف اسم الملف، ويختار أحدث ZIP تم رفعه، ثم يستخرج الملفات ويبحث عن `index.html` وينشر المجلد الذي يحتويه.

## تنبيه مهم
GitHub لا يشغّل Workflow الموجود داخل ZIP بمجرد رفع ZIP. لذلك يجب أن يكون ملف `.github/workflows/deploy-pages.yml` مثبتًا بالفعل في المستودع مرة واحدة. بعد ذلك يمكنك رفع ZIP وحده وتشغيل النشر تلقائيًا.

## رابط الموقع
https://echchiaa95.github.io/Salon/

## Supabase
قاعدة البيانات ودوال Edge Functions لا تُنشر عبر GitHub Pages. ملفات SQL والدوال موجودة في مجلد `supabase/` ويجب نشرها في Supabase بصورة منفصلة.
