# Beauty & Spa — Starter Project

واجهة عربية RTL مع قالب HTML، مخطط قاعدة بيانات Supabase، ووظيفتين خلفيتين أوليتين للطلبات والحجوزات.

**مهم:** هذه حزمة بداية وليست نظاماً إنتاجياً مكتملاً. `public/index.html` لا يتصل بعد بـ Supabase؛ بعض وظائف لوحة الإدارة والطلبات والحجوزات تجريبية ومحلية. راجع `WORKFLOW_AR.md` للحصول على سير العمل الموحد من الهاتف.

## المحتويات
- `public/index.html` — واجهة HTML أولية.
- `supabase/schema.sql` — مخطط قاعدة البيانات والسياسات الأولية.
- `supabase/functions/create-order/index.ts` — وظيفة خلفية أولية للطلبات.
- `supabase/functions/create-booking/index.ts` — وظيفة خلفية أولية للحجوزات.
- `.github/workflows/deploy-pages.yml` — سير نشر GitHub Pages عبر Actions.
- `WORKFLOW_AR.md` — تعليمات موحدة باللغة العربية.

## أسرار ومفاتيح
لا تضع `service_role` أو Secret key في ملفات الواجهة أو GitHub. استخدم Publishable key فقط في المتصفح مع RLS سليمة، والمفتاح السري داخل الوظائف الخلفية فقط.
