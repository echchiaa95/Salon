# Beauty & Spa

## GitHub Pages deployment
1. Extract this ZIP on your device.
2. Upload **all files and folders inside the ZIP** to the root of the GitHub repository `Salon` (not the ZIP archive itself). Keep the `.github/workflows/deploy-pages.yml` path.
3. Ensure the default branch is `main`.
4. In Settings → Pages, select **GitHub Actions** as the build and deployment source.
5. Open Actions and wait for **Deploy Beauty & Spa to GitHub Pages** to succeed.
6. Project site URL: https://echchiaa95.github.io/Salon/

The deployment workflow publishes the root `index.html`, or falls back to `public/index.html`. If neither exists in the repository, the workflow intentionally fails with a diagnostic message.

## Supabase
- SQL schema: `supabase/schema.sql`
- Edge Functions: `supabase/functions/create-order` and `supabase/functions/create-booking`
- `.env.example` is a template only. Supabase Edge Functions must be deployed separately using the Supabase CLI; GitHub Pages does not deploy backend functions.
